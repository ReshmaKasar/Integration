﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using IntegrationInterface.IntegrationMasterInterface.CommonInterface;


namespace IntegrationWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserCreationController : ControllerBase
    {
        UserCreationInterface usercreation;
        UserCreationController(UserCreationInterface init)
        {
            usercreation = init;
        }
        [HttpGet]
        public void GetAllUser()
        {
            usercreation.GetData();
        }
    }
}
