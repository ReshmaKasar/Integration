﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace IntegrationMailSystem.Mail
{
    public class IntegrationMail
    {
        public void SendMail(string To,string subject,string body)
        {
            try
            {
                SmtpClient smtpClient = new SmtpClient();
                smtpClient.Host = "smtp.gmail.com";
                smtpClient.Port = 578;
                //smtpClient.UserCredential = false;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials =new System.Net.NetworkCredential("ToMailId", "Password");
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        
    }
}
