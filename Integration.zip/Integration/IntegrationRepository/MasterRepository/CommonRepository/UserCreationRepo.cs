﻿using IntegrationClsFunction.CommonFunction;
using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel.IntegrationErrorModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace IntegrationRepository.MasterRepository.CommonRepository
{
    public class UserCreationRepo : IUserCreationInterface
    {
        public List<UserCreationModel> GetData()
        {
            UserCreationModel model = null;
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.fetchdata("UserCreation", 0);
            //UserCreationModel umodel = new UserCreationModel();
            var _list = new List<UserCreationModel>();
            try
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    model = new UserCreationModel();
                    {
                        model.UserId = (int)dt.Rows[i]["UserId"];
                        model.UserName = (string)dt.Rows[i]["UserName"];
                        model.Password = (string)dt.Rows[i]["Password"];
                    }
                    _list.Add(model);
                }
                
            }
            catch(Exception x)
            {
                ErrorLogModel errorLog = new ErrorLogModel();
                errorLog.ErrorCode = "01";
                errorLog.ErrorMassage = Convert.ToString(x);
                errorLog.ErrorStackTrace = Convert.ToString(x);
                errorLog.ErrorLineNo = Convert.ToString(x);
                errorLog.ErrorData = Convert.ToString(DateTime.Now); //problem
                errorLog.ErrorDateTime = Convert.ToString(DateTime.Now); //problem
                errorLog.SolvesStatus = Convert.ToString(x);
                errorLog.DeveloperName = "Sp";
                errorLog.FormName = Convert.ToString(x);
                errorLog.FunctionName = Convert.ToString(GetData());
                errorLog.ClassName = Convert.ToString(x);
                errorLog.RepoName = Convert.ToString(x);
                errorLog.UserId = Convert.ToInt32(model.UserId);
                errorLog.flag = "i";
            }
            return _list;
        }

        public void PostData(UserCreationModel model)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            SqlCommand sqlcmd = new SqlCommand();
            string AcFlag = "Y";
            sqlcmd.Connection = sqlcon;
            sqlcmd.CommandText = "spUserCreation";
            sqlcmd.CommandType = CommandType.StoredProcedure;

            if(model.UserId ==0)
            {
                string flag = "i";
                sqlcmd.Parameters.AddWithValue("flag", flag);
            }
            else
            {
                string flag = "u";
                sqlcmd.Parameters.AddWithValue("flag", flag);
            }


            sqlcmd.Parameters.AddWithValue("@UserId", model.UserId);
            sqlcmd.Parameters.AddWithValue("@UserName", model.UserName);
            sqlcmd.Parameters.AddWithValue("@Password",model.Password);
            sqlcmd.Parameters.AddWithValue("@AcFlag", AcFlag);
            sqlcmd.ExecuteNonQuery();
        }
       

        public List<UserCreationModel> GetById(int id)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.fetchdata("UserCreation", id);
            var _list = new List<UserCreationModel>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                UserCreationModel model = new UserCreationModel();
                {
                    model.UserId = (int)dt.Rows[i]["UserId"];
                    model.UserName = (string)dt.Rows[i]["UserName"];
                    model.Password = (string)dt.Rows[i]["Password"];
                }
                _list.Add(model);
            }
            return _list;

        }

        public List<UserCreationModel> GetByName(string name)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.FetchName("UserCreation",name);
            var _list = new List<UserCreationModel>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                UserCreationModel model = new UserCreationModel();
                {
                    model.UserId = (int)dt.Rows[i]["UserId"];
                    model.UserName = (string)dt.Rows[i]["UserName"];
                    model.Password = (string)dt.Rows[i]["Password"];
                }
                _list.Add(model);
            }
            return _list;
        }

        public void DeleteById(int id)
        {
            ClsFunction cls = new ClsFunction();
            cls.DeleteById("UserCreation",id);
        }

        //public UserCreationModel GetById(int id)
        //{
        //    //dt = UserCreationModel = new UserCreationModel();
        //}
    }
}
