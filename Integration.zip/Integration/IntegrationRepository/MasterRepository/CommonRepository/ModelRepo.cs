﻿using IntegrationClsFunction.CommonFunction;
using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using IntegrationRepository.MasterRepository.CommonRepository;
using IntegrationModels.IntegrationMasterModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel.IntegrationErrorModel;
using System.Data.SqlClient;
using System.Reflection;

namespace IntegrationRepository.MasterRepository.CommonRepository
{
    public class ModelRepo : IModelInterface
    {
        public List<ModelModel> GetById(int id)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.fetchdata("Models", id);
            var _list = new List<ModelModel>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ModelModel model = new ModelModel();
                {
                    model.ModelId = (int)dt.Rows[i]["ModelId"];
                    model.FeedMill = (string)dt.Rows[i]["FeedMill"];
                    model.Hitechary = (string)dt.Rows[i]["Hitechary"];
                    model.Integration = (string)dt.Rows[i]["Integration"];
                    model.Breater = (string)dt.Rows[i]["Breater"];
                }
                _list.Add(model);
            }
            return _list;
        }

        public void DeleteById(int id)
        {
            ClsFunction cls = new ClsFunction();
            cls.DeleteById("Models", id);
        }

        public List<ModelModel> GetModels()
        {
            ModelModel model = null;
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.fetchdata("Models", 0);
            //ModelModel gmodel = new ModelModel();
            var _list = new List<ModelModel>();
            try
            {

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    model = new ModelModel();
                    {
                        model.ModelId = (int)dt.Rows[i]["ModelId"];
                        model.FeedMill = (string)dt.Rows[i]["FeedMill"];
                        model.Hitechary = (string)dt.Rows[i]["Hitechary"];
                        model.Integration = (string)dt.Rows[i]["Integration"];
                        model.Breater = (string)dt.Rows[i]["Breater"];
                    }
                    _list.Add(model);
                }
            }
            catch(Exception x)
            {
                ErrorLogModel errorLog = new ErrorLogModel();
                errorLog.ErrorCode = "01";
                errorLog.ErrorMassage = Convert.ToString(x);
                errorLog.ErrorStackTrace = Convert.ToString(x);
                errorLog.ErrorLineNo = Convert.ToString(x);
                errorLog.ErrorData = Convert.ToString(DateTime.Now); //problem
                errorLog.ErrorDateTime = Convert.ToString(DateTime.Now); //problem
                errorLog.SolvesStatus = Convert.ToString(x);
                errorLog.DeveloperName = "Sp";
                errorLog.FormName = Convert.ToString(x);
                errorLog.FunctionName = Convert.ToString(GetModels());
                errorLog.ClassName = Convert.ToString(x);
                errorLog.RepoName = Convert.ToString(x);
                errorLog.UserId = Convert.ToInt32(model.ModelId);
                errorLog.flag = "i";
            }
            return _list;
        }

        public void PostData(ModelModel model)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            SqlCommand sqlcmd = new SqlCommand();
            sqlcmd.Connection = sqlcon;
            sqlcmd.CommandText = "spModels";
            sqlcmd.CommandType = CommandType.StoredProcedure;

            string AcFlag = "Y";
            if (model.ModelId == 0)
            {
                string flag = "i";
                sqlcmd.Parameters.AddWithValue("flag", flag);
            }
            else
            {
                string flag = "u";
                sqlcmd.Parameters.AddWithValue("flag", flag);
            }

            sqlcmd.Parameters.AddWithValue("@ModelId", model.ModelId);
            sqlcmd.Parameters.AddWithValue("@FeedMill", model.FeedMill);
            sqlcmd.Parameters.AddWithValue("@Hitechary", model.Hitechary);
            sqlcmd.Parameters.AddWithValue("@Integration", model.Integration);
            sqlcmd.Parameters.AddWithValue("@Breater", model.Breater);
            sqlcmd.Parameters.AddWithValue("@AcFlag", AcFlag);
            sqlcmd.ExecuteNonQuery();
        }

        public List<ModelModel> GetByName(string name)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.FetchName("Models", name);
            var _list = new List<ModelModel>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ModelModel model = new ModelModel();
                {
                    model.ModelId = (int)dt.Rows[i]["ModelId"];
                    model.FeedMill = (string)dt.Rows[i]["FeedMill"];
                    model.Hitechary = (string)dt.Rows[i]["Hitechary"];
                    model.Integration = (string)dt.Rows[i]["Integration"];
                    model.Breater = (string)dt.Rows[i]["Breater"];
                }
                _list.Add(model);
            }
            return _list;
        }
    }
}
