﻿using IntegrationClsFunction.CommonFunction;
using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel.IntegrationErrorModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntegrationRepository.MasterRepository.CommonRepository
{
    public class PersonRepo : IPersonInterface
    {
        public List<PersonModel> GetById(int id)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.fetchdata("Person", id);
            var _list = new List<PersonModel>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                PersonModel model = new PersonModel();
                {
                    model.PersonId = (int)dt.Rows[i]["PersonId"];
                    model.PersonCode = (int)dt.Rows[i]["PersonCode"];
                    model.PersonType = (string)dt.Rows[i]["PersonType"];
                    model.PersonName = (string)dt.Rows[i]["PersonName"];
                    model.PersonAddress = (string)dt.Rows[i]["PersonAddress"];
                    model.PersonContact = (string)dt.Rows[i]["PersonContact"];
                    model.PersonEmail = (string)dt.Rows[i]["PersonEmail"];
                    model.PersonBankId = (int)dt.Rows[i]["PersonBankId"];
                }
                _list.Add(model);
            }
            return _list;
        }
        public void DeleteById(int id)
        {
            ClsFunction cls = new ClsFunction();
            cls.DeleteById("Person", id);
        }

        public List<PersonModel> GetPersons()
        {
            PersonModel model = null;
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.fetchdata("Person", 0);
            //PersonModel pmodel = new PersonModel();
            var _list = new List<PersonModel>();
            try
            {

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    model = new PersonModel();
                    {
                        model.PersonId = (int)dt.Rows[i]["PersonId"];
                        model.PersonCode = (int)dt.Rows[i]["PersonCode"];
                        model.PersonType = (string)dt.Rows[i]["PersonType"];
                        model.PersonName = (string)dt.Rows[i]["PersonName"];
                        model.PersonAddress = (string)dt.Rows[i]["PersonAddress"];
                        model.PersonContact = (string)dt.Rows[i]["PersonContact"];
                        model.PersonEmail = (string)dt.Rows[i]["PersonEmail"];
                        model.PersonBankId = (int)dt.Rows[i]["PersonBankId"];
                    }
                    _list.Add(model);
                }
            }
            catch(Exception x)
            {
                ErrorLogModel errorLog = new ErrorLogModel();
                errorLog.ErrorCode = "01";
                errorLog.ErrorMassage = Convert.ToString(x);
                errorLog.ErrorStackTrace = Convert.ToString(x);
                errorLog.ErrorLineNo = Convert.ToString(x);
                errorLog.ErrorData = Convert.ToString(DateTime.Now); //problem
                errorLog.ErrorDateTime = Convert.ToString(DateTime.Now); //problem
                errorLog.SolvesStatus = Convert.ToString(x);
                errorLog.DeveloperName = "Sp";
                errorLog.FormName = Convert.ToString(x);
                errorLog.FunctionName = Convert.ToString(GetPersons());
                errorLog.ClassName = Convert.ToString(x);
                errorLog.RepoName = Convert.ToString(x);
                errorLog.UserId = Convert.ToInt32(model.PersonId);
                errorLog.flag = "i";
            }
            return _list;
        }

        public void PostData(PersonModel model)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            SqlCommand sqlcmd = new SqlCommand();
            sqlcmd.Connection = sqlcon;
            sqlcmd.CommandText = "spPerson";
            sqlcmd.CommandType = CommandType.StoredProcedure;

            string AcFlag = "Y";
            if (model.PersonId == 0)
            {
                string flag = "i";
                sqlcmd.Parameters.AddWithValue("flag", flag);
            }
            else
            {
                string flag = "u";
                sqlcmd.Parameters.AddWithValue("flag", flag);
            }

            sqlcmd.Parameters.AddWithValue("@PersonId", model.PersonId);
            sqlcmd.Parameters.AddWithValue("@PersonCode", model.PersonCode);
            sqlcmd.Parameters.AddWithValue("@PersonType", model.PersonType);
            sqlcmd.Parameters.AddWithValue("@PersonName", model.PersonName);
            sqlcmd.Parameters.AddWithValue("@PersonAddress", model.PersonAddress);
            sqlcmd.Parameters.AddWithValue("@PersonContact", model.PersonContact);
            sqlcmd.Parameters.AddWithValue("@PersonEmail", model.PersonEmail);
            sqlcmd.Parameters.AddWithValue("@PersonBankId", model.PersonBankId);
            sqlcmd.Parameters.AddWithValue("@AcFlag", AcFlag);
            sqlcmd.ExecuteNonQuery();
        }

        public List<PersonModel> GetByName(string name)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.FetchName("Person", name);
            var _list = new List<PersonModel>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                PersonModel model = new PersonModel();
                {
                    model.PersonId = (int)dt.Rows[i]["PersonId"];
                    model.PersonCode = (int)dt.Rows[i]["PersonCode"];
                    model.PersonType = (string)dt.Rows[i]["PersonType"];
                    model.PersonName = (string)dt.Rows[i]["PersonName"];
                    model.PersonAddress = (string)dt.Rows[i]["PersonAddress"];
                    model.PersonContact = (string)dt.Rows[i]["PersonContact"];
                    model.PersonEmail = (string)dt.Rows[i]["PersonEmail"];
                    model.PersonBankId = (int)dt.Rows[i]["PersonBankId"];
                }
                _list.Add(model);
            }
            return _list;
        }
    }
}
