﻿using IntegrationClsFunction.CommonFunction;
using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel.IntegrationErrorModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntegrationRepository.MasterRepository.CommonRepository
{
    public class ItemRepo : IItemInterface
    {
        public List<ItemModel> GetById(int id)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.fetchdata("Item", id);
            var _list = new List<ItemModel>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ItemModel model = new ItemModel();
                {
                    model.ItemId = (int)dt.Rows[i]["ItemId"];
                    model.ItemName = (string)dt.Rows[i]["ItemName"];
                    model.ItemCode = (string)dt.Rows[i]["ItemCode"];
                    model.ProdcutId = (int)dt.Rows[i]["ProdcutId"];
                    model.ItemStd = (int)dt.Rows[i]["ItemStd"];
                }
                _list.Add(model);
            }
            return _list;
        }

        public void DeleteById(int id)
        {
            ClsFunction cls = new ClsFunction();
            cls.DeleteById("Item", id);
        }

        public List<ItemModel> GetItems()
        {
            ItemModel model = null;
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.fetchdata("Item",0);
            //ItemModel imodel = new ItemModel();
            var _list = new List<ItemModel>();
            try
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    model = new ItemModel();
                    {
                        model.ItemId = (int)dt.Rows[i]["ItemId"];
                        model.ItemName = (string)dt.Rows[i]["ItemName"];
                        model.ItemCode = (string)dt.Rows[i]["ItemCode"];
                        model.ProdcutId = (int)dt.Rows[i]["ProductId"];
                        model.ItemStd = (int)dt.Rows[i]["ItemStd"];
                    }
                    _list.Add(model);
                }
            }
            catch(Exception x)
            {
                ErrorLogModel errorLog = new ErrorLogModel();
                errorLog.ErrorCode = "01";
                errorLog.ErrorMassage = Convert.ToString(x);
                errorLog.ErrorStackTrace = Convert.ToString(x);
                errorLog.ErrorLineNo = Convert.ToString(x);
                errorLog.ErrorData = Convert.ToString(DateTime.Now); //problem
                errorLog.ErrorDateTime = Convert.ToString(DateTime.Now); //problem
                errorLog.SolvesStatus = Convert.ToString(x);
                errorLog.DeveloperName = "Sp";
                errorLog.FormName = Convert.ToString(x);
                errorLog.FunctionName = Convert.ToString(GetItems());
                errorLog.ClassName = Convert.ToString(x);
                errorLog.RepoName = Convert.ToString(x);
                errorLog.UserId = Convert.ToInt32(model.ItemId);
                errorLog.flag = "i";
            }
            return _list;
        }

        public void PostData(ItemModel model)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            SqlCommand sqlcmd = new SqlCommand();
            sqlcmd.Connection = sqlcon;
            sqlcmd.CommandText = "spItem";
            sqlcmd.CommandType = CommandType.StoredProcedure;

            string AcFlag = "Y";
            if (model.ItemId == 0)
            {
                string flag = "i";
                sqlcmd.Parameters.AddWithValue("flag", flag);
            }
            else
            {
                string flag = "u";
                sqlcmd.Parameters.AddWithValue("flag", flag);
            }


            sqlcmd.Parameters.AddWithValue("@ItemId", model.ItemId);
            sqlcmd.Parameters.AddWithValue("@ItemName", model.ItemName);
            sqlcmd.Parameters.AddWithValue("@ItemCode", model.ItemCode);
            sqlcmd.Parameters.AddWithValue("@ProductId", model.ProdcutId);
            sqlcmd.Parameters.AddWithValue("@ItemStd", model.ItemStd);
            sqlcmd.Parameters.AddWithValue("@AcFlag", AcFlag);
            sqlcmd.ExecuteNonQuery();
        }

        public List<ItemModel> GetByName(string name)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.FetchName("Item", name);
            var _list = new List<ItemModel>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ItemModel model = new ItemModel();
                {
                    model.ItemId = (int)dt.Rows[i]["ItemId"];
                    model.ItemName = (string)dt.Rows[i]["ItemName"];
                    model.ItemCode = (string)dt.Rows[i]["ItemCode"];
                    model.ProdcutId = (int)dt.Rows[i]["ProductId"];
                    model.ItemStd = (int)dt.Rows[i]["ItemStd"];
                }
                _list.Add(model);
            }
            return _list;
        }

        public List<ItemModel> ItemDropDown()
        {
            string itemlist = "select ItemId,ItemName from Item where AcFlag='Y';";
            Connection conn = new Connection();
            SqlConnection sqlConnection = conn.GetConnection();
            ClsFunction cLSFuncation = new ClsFunction();
            DataTable dt = cLSFuncation.FetchDataTableQuery(itemlist);
            ErrorLogModel errorLog = new ErrorLogModel();
            //var emodel = new ItemModel();
            var _list = new List<ItemModel>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ItemModel model = new ItemModel();
                {
                    model.ItemId = (int)dt.Rows[i]["ItemId"];
                    model.ItemName = (string)dt.Rows[i]["ItemName"];
                    
                }
                _list.Add(model);
            }
            return _list;
            
        }

       
    }
}
