﻿using IntegrationClsFunction.CommonFunction;
using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel.IntegrationErrorModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntegrationRepository.MasterRepository.CommonRepository
{
    public class CompanyRepo : ICompanyInterface
    {
        public List<CompanyModel> GetById(int id)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.fetchdata("Company", id);
            var _list = new List<CompanyModel>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                CompanyModel model = new CompanyModel();
                {
                    model.CompanyId = (int)dt.Rows[i]["CompanyId"];
                    model.CompanyName = (string)dt.Rows[i]["CompanyName"];
                    model.Companyemail = (string)dt.Rows[i]["Companyemail"];
                    model.CompanyContact = (string)dt.Rows[i]["CompanyContact"];
                    model.CompanyLogo = (string)dt.Rows[i]["CompanyLogo"];
                }
                _list.Add(model);
            }
            return _list;
        }

        public void DeleteById(int id)
        {
            ClsFunction cls = new ClsFunction();
            cls.DeleteById("Company", id);
        }

        public List<CompanyModel> GetCompanys()
        {
            CompanyModel model = null;
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.fetchdata("Company", 0);
            //CompanyModel cmodel = new CompanyModel();
            var _list = new List<CompanyModel>();
            
            try
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    model = new CompanyModel();
                    {
                        model.CompanyId = (int)dt.Rows[i]["CompanyId"];
                        model.CompanyName = (string)dt.Rows[i]["CompanyName"];
                        model.Companyemail = (string)dt.Rows[i]["Companyemail"];
                        model.CompanyContact = (string)dt.Rows[i]["CompanyContact"];
                        model.CompanyLogo = (string)dt.Rows[i]["CompanyLogo"];
                    }
                    _list.Add(model);
                }
            }
            catch(Exception x)
            {
                ErrorLogModel errorLog = new ErrorLogModel();
                errorLog.ErrorCode = "01";
                errorLog.ErrorMassage = Convert.ToString(x);
                errorLog.ErrorStackTrace = Convert.ToString(x);
                errorLog.ErrorLineNo = Convert.ToString(x);
                errorLog.ErrorData = Convert.ToString(DateTime.Now); //problem
                errorLog.ErrorDateTime = Convert.ToString(DateTime.Now); //problem
                errorLog.SolvesStatus = Convert.ToString(x);
                errorLog.DeveloperName = "Sp";
                errorLog.FormName = Convert.ToString(x);
                errorLog.FunctionName = Convert.ToString(GetCompanys());
                errorLog.ClassName = Convert.ToString(x);
                errorLog.RepoName = Convert.ToString(x);
                errorLog.UserId = Convert.ToInt32(model.CompanyId);
                errorLog.flag = "i";
            }
            return _list;
        }

        public void PostData(CompanyModel model)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            SqlCommand sqlcmd = new SqlCommand();
            sqlcmd.Connection = sqlcon;
            sqlcmd.CommandText = "spCompany";
            sqlcmd.CommandType = CommandType.StoredProcedure;

            string AcFlag = "Y";
            if (model.CompanyId == 0)
            {
                string flag = "i";
                sqlcmd.Parameters.AddWithValue("flag", flag);
            }
            else
            {
                string flag = "u";
                sqlcmd.Parameters.AddWithValue("flag", flag);
            }

            sqlcmd.Parameters.AddWithValue("@CompanyId", model.CompanyId);
            sqlcmd.Parameters.AddWithValue("@CompanyName", model.CompanyName);
            sqlcmd.Parameters.AddWithValue("@CompanyEmail", model.Companyemail);
            sqlcmd.Parameters.AddWithValue("@CompanyContact", model.CompanyContact);
            sqlcmd.Parameters.AddWithValue("@CompanyLogo", model.CompanyLogo);
            sqlcmd.Parameters.AddWithValue("@AcFlag", AcFlag);
            sqlcmd.ExecuteNonQuery();
        }

        public List<CompanyModel> GetByName(string name)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.FetchName("Company", name);
            var _list = new List<CompanyModel>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                CompanyModel model = new CompanyModel();
                {
                    model.CompanyId = (int)dt.Rows[i]["CompanyId"];
                    model.CompanyName = (string)dt.Rows[i]["CompanyName"];
                    model.Companyemail = (string)dt.Rows[i]["Companyemail"];
                    model.CompanyContact = (string)dt.Rows[i]["CompanyContact"];
                    model.CompanyLogo = (string)dt.Rows[i]["CompanyLogo"];
                }
                _list.Add(model);
            }
            return _list;
        }
    }
}
