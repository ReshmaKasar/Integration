﻿using IntegrationClsFunction.CommonFunction;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel.IntegrationErrorModel;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IntegrationInterface.IntegrationMasterInterface.CommonInterface;

namespace IntegrationRepository.MasterRepository.CommonRepository
{
    public class BranchRepository : IBranch
    {
        public List<BranchModel> GetData()   //------------------- //Get All Branch-------------------------
        {
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.fetchdata("Branch", 0);
            ErrorLogModel errorLog = new ErrorLogModel();
            var _list = new List<BranchModel>();
            try
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    BranchModel bmodel = new BranchModel();
                    {
                        bmodel.BranchId = (int)dt.Rows[i]["BranchId"];
                        bmodel.BranchName = (string)dt.Rows[i]["BranchName"];
                        bmodel.CompanyId = (int)dt.Rows[i]["CompanyId"];
                    }
                    _list.Add(bmodel);
                }
            }
            catch (Exception x)
            {

                errorLog.ErrorCode = "01";
                errorLog.ErrorMassage = Convert.ToString(x);
                errorLog.ErrorStackTrace = Convert.ToString(x);
                errorLog.ErrorLineNo = Convert.ToString(x);
                errorLog.ErrorData = Convert.ToString(DateTime.Now); //problem
                errorLog.ErrorDateTime = Convert.ToString(DateTime.Now); //problem
                errorLog.SolvesStatus = Convert.ToString(x);
                errorLog.DeveloperName = "Sp";
                errorLog.FormName = Convert.ToString(x);
                errorLog.FunctionName = Convert.ToString(GetData());
                errorLog.ClassName = Convert.ToString(x);
                errorLog.RepoName = Convert.ToString(x);
                //errorLog.UserId = Convert.ToInt32(umodel.UserId);
                errorLog.flag = "i";
            }
            return _list;
        }

        public List<BranchModel> GetById(int id) //------------------- //Get By Id-------------------------
        {
            Connection conn = new Connection();
            SqlConnection sqlConnection = conn.GetConnection();
            ClsFunction cLSFuncation = new ClsFunction();
            ErrorLogModel errorLog = new ErrorLogModel();
            DataTable dt = cLSFuncation.fetchdata("Branch", id);
            var _list = new List<BranchModel>();

            try
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    BranchModel bmodel = new BranchModel();
                    {
                        bmodel.BranchId = (int)dt.Rows[i]["BranchId"];
                        bmodel.BranchName = (string)dt.Rows[i]["BranchName"];
                        bmodel.CompanyId = (int)dt.Rows[i]["CompanyId"];
                    }
                    _list.Add(bmodel);
                }
            }
            catch (Exception x)
            {

                errorLog.ErrorCode = "01";
                errorLog.ErrorMassage = Convert.ToString(x);
                errorLog.ErrorStackTrace = Convert.ToString(x);
                errorLog.ErrorLineNo = Convert.ToString(x);
                errorLog.ErrorData = Convert.ToString(DateTime.Now); //problem
                errorLog.ErrorDateTime = Convert.ToString(DateTime.Now); //problem
                errorLog.SolvesStatus = Convert.ToString(x);
                errorLog.DeveloperName = "Sp";
                errorLog.FormName = Convert.ToString(x);
                errorLog.FunctionName = Convert.ToString(GetById(id));
                errorLog.ClassName = Convert.ToString(x);
                errorLog.RepoName = Convert.ToString(x);
                //errorLog.UserId = Convert.ToInt32(umodel.UserId);
                errorLog.flag = "i";
            }
            return _list;
        }

        public List<BranchModel> GetByName(string name) //------------------- //Get By Name-------------------------
        {
            Connection conn = new Connection();
            SqlConnection sqlConnection = conn.GetConnection();
            ClsFunction cLSFuncation1 = new ClsFunction();
            ErrorLogModel errorLog = new ErrorLogModel();
            DataTable dt = cLSFuncation1.FetchName("Branch", name);
            var _list = new List<BranchModel>();

            try
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    BranchModel bmodel = new BranchModel();
                    {
                        bmodel.BranchId = (int)dt.Rows[i]["BranchId"];
                        bmodel.BranchName = (string)dt.Rows[i]["BranchName"];
                        bmodel.CompanyId = (int)dt.Rows[i]["CompanyId"];
                    }
                    _list.Add(bmodel);
                }
            }
            catch (Exception x)
            {

                errorLog.ErrorCode = "01";
                errorLog.ErrorMassage = Convert.ToString(x);
                errorLog.ErrorStackTrace = Convert.ToString(x);
                errorLog.ErrorLineNo = Convert.ToString(x);
                errorLog.ErrorData = Convert.ToString(DateTime.Now); //problem
                errorLog.ErrorDateTime = Convert.ToString(DateTime.Now); //problem
                errorLog.SolvesStatus = Convert.ToString(x);
                errorLog.DeveloperName = "Sp";
                errorLog.FormName = Convert.ToString(x);
                errorLog.FunctionName = Convert.ToString(GetByName(name));
                errorLog.ClassName = Convert.ToString(x);
                errorLog.RepoName = Convert.ToString(x);
                //errorLog.UserId = Convert.ToInt32(umodel.UserId);
                errorLog.flag = "i";
            }
            return _list;
        }
        public void GetPost(BranchModel umodel)   //---------------------//Post-----------------------
        {

            Connection connection = new Connection();
            SqlConnection sqlConnection = connection.GetConnection();
            ErrorLogModel errorLog = new ErrorLogModel();
            SqlCommand sqlCommand = new SqlCommand();
            string Acflag = "Y";


            sqlCommand.Connection = sqlConnection;
            sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
            sqlCommand.CommandText = "SpBranchCreation";
            if (umodel.BranchId == 0)
            {
                string flag = "i";
                sqlCommand.Parameters.AddWithValue("@flag", flag);
            }
            else
            {
                string flag = "u";
                sqlCommand.Parameters.AddWithValue("@flag", flag);
            }
            sqlCommand.Parameters.AddWithValue("@BranchId", umodel.BranchId);
            sqlCommand.Parameters.AddWithValue("@BranchName", umodel.BranchName);
            sqlCommand.Parameters.AddWithValue("@CompanyId", umodel.CompanyId);
            sqlCommand.Parameters.AddWithValue("@AcFlag", Acflag);

            try
            {
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception x)
            {

                errorLog.ErrorCode = "01";
                errorLog.ErrorMassage = Convert.ToString(x);
                errorLog.ErrorStackTrace = Convert.ToString(x);
                errorLog.ErrorLineNo = Convert.ToString(x);
                errorLog.ErrorData = Convert.ToString(DateTime.Now); //problem
                errorLog.ErrorDateTime = Convert.ToString(DateTime.Now); //problem
                errorLog.SolvesStatus = Convert.ToString(x);
                errorLog.DeveloperName = "Sp";
                errorLog.FormName = Convert.ToString(x);
                errorLog.FunctionName = Convert.ToString(x);
                errorLog.ClassName = Convert.ToString(x);
                errorLog.RepoName = Convert.ToString(x);
                //errorLog.UserId = Convert.ToInt32(umodel.UserId);
                errorLog.flag = "i";
            }
        }
        public void DeleteById(int id) //------------------- //DeleteById-------------------------
        {
            ClsFunction cLSFuncation = new ClsFunction();
            cLSFuncation.DeleteById("Branch", id);
        }
        public List<CompanyModel> CompanyDropDown() //------------Company Drop Down--------
        {
            string cmplist = "select CompanyId,CompanyName from Company where Acflag='Y';";
            Connection conn = new Connection();
            SqlConnection sqlConnection = conn.GetConnection();
            ClsFunction cLSFuncation = new ClsFunction();
            DataTable dt = cLSFuncation.FetchDataTableQuery(cmplist);
            ErrorLogModel errorLog = new ErrorLogModel();
            var cmodel = new CompanyModel();
            var _list = new List<CompanyModel>();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                cmodel.CompanyId = (int)dt.Rows[i]["CompanyId"];
                cmodel.CompanyName = (string)dt.Rows[i]["CompanyName"];
            }
            _list.Add(cmodel);
            return _list;
        }

        public List<BranchModel> Companyid(int cid) //------------Branch Drop Down--------
        {
            string cmplist = "SELECT BranchId,BranchName from Branch where AcFlag='Y' and CompanyId=" + cid;
            Connection conn = new Connection();
            SqlConnection sqlConnection = conn.GetConnection();
            ClsFunction cLSFuncation = new ClsFunction();
            DataTable dt = cLSFuncation.FetchDataTableQuery(cmplist);
            ErrorLogModel errorLog = new ErrorLogModel();
            //var cmodel = new BranchModel();
            var _list = new List<BranchModel>();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                BranchModel bmodel = new BranchModel();
                {
                    bmodel.BranchId = (int)dt.Rows[i]["BranchId"];
                    bmodel.BranchName = (string)dt.Rows[i]["BranchName"];
                }
                _list.Add(bmodel);
            }
            return _list;
        }

    }
}

