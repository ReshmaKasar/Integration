﻿using IntegrationClsFunction.CommonFunction;
using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel.IntegrationErrorModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace IntegrationRepository.MasterRepository.CommonRepository
{
    public class EmployeeRepo : IEmployeeInterface
    {
        public List<EmployeeModel> GetById(int id)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.fetchdata("Employee", id);
            var _list = new List<EmployeeModel>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                EmployeeModel model = new EmployeeModel();
                {
                    model.EmpId = (int)dt.Rows[i]["EmpId"];
                    model.EmpCode = (string)dt.Rows[i]["EmpCode"];
                    model.EmpName = (string)dt.Rows[i]["EmpName"];
                    model.EmpContact = (string)dt.Rows[i]["EmpContact"];
                    model.EmpEmail = (string)dt.Rows[i]["EmpEmail"];
                    model.EmpAddress = (string)dt.Rows[i]["EmpAddress"];
                }
                _list.Add(model);
            }
            return _list;
        }

        public void DeleteById(int id)
        {
            ClsFunction cls = new ClsFunction();
            cls.DeleteById("Employee", id);
        }

        public List<EmployeeModel> GetEmployees()
        {
            EmployeeModel model = null;
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.fetchdata("Employee", 0);
            //EmployeeModel emodel = new EmployeeModel();
            var _list = new List<EmployeeModel>();
            try
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    model = new EmployeeModel();
                    {
                        model.EmpId = (int)dt.Rows[i]["EmpId"];
                        model.EmpCode = (string)dt.Rows[i]["EmpCode"];
                        model.EmpName = (string)dt.Rows[i]["EmpName"];
                        model.EmpContact = (string)dt.Rows[i]["EmpContact"];
                        model.EmpEmail = (string)dt.Rows[i]["EmpEmail"];
                        model.EmpAddress = (string)dt.Rows[i]["EmpAddress"];
                    }
                    _list.Add(model);
                }
            }
            catch(Exception x)
            {
                ErrorLogModel errorLog = new ErrorLogModel();
                errorLog.ErrorCode = "01";
                errorLog.ErrorMassage = Convert.ToString(x);
                errorLog.ErrorStackTrace = Convert.ToString(x);
                errorLog.ErrorLineNo = Convert.ToString(x);
                errorLog.ErrorData = Convert.ToString(DateTime.Now); //problem
                errorLog.ErrorDateTime = Convert.ToString(DateTime.Now); //problem
                errorLog.SolvesStatus = Convert.ToString(x);
                errorLog.DeveloperName = "Sp";
                errorLog.FormName = Convert.ToString(x);
                errorLog.FunctionName = Convert.ToString(GetEmployees());
                errorLog.ClassName = Convert.ToString(x);
                errorLog.RepoName = Convert.ToString(x);
                errorLog.UserId = Convert.ToInt32(model.EmpId);
                errorLog.flag = "i";
            }
            return _list;
        }

        public void PostData(EmployeeModel model)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            SqlCommand sqlcmd = new SqlCommand();
            sqlcmd.Connection = sqlcon;
            sqlcmd.CommandText = "spEmployee";
            sqlcmd.CommandType = CommandType.StoredProcedure;
            string empcode = GenerateEmpcode();
            string AcFlag = "Y";
            if (model.EmpId == 0)
            {
                string flag = "i";
                sqlcmd.Parameters.AddWithValue("flag", flag);
            }
            else
            {
                string flag = "u";
                sqlcmd.Parameters.AddWithValue("flag", flag);
            }

            sqlcmd.Parameters.AddWithValue("@EmpId", model.EmpId);
            sqlcmd.Parameters.AddWithValue("@EmpCode", empcode);
            sqlcmd.Parameters.AddWithValue("@EmpName", model.EmpName);
            sqlcmd.Parameters.AddWithValue("@EmpContact", model.EmpContact);
            sqlcmd.Parameters.AddWithValue("@EmpEmail", model.EmpEmail);
            sqlcmd.Parameters.AddWithValue("@EmpAddress", model.EmpAddress);
            sqlcmd.Parameters.AddWithValue("@AcFlag", AcFlag);
            sqlcmd.ExecuteNonQuery();
        }

        public List<EmployeeModel> GetByName(string name)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.FetchName("Employee", name);
            var _list = new List<EmployeeModel>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                EmployeeModel model = new EmployeeModel();
                {
                    model.EmpId = (int)dt.Rows[i]["EmpId"];
                    model.EmpCode = (string)dt.Rows[i]["EmpCode"];
                    model.EmpName = (string)dt.Rows[i]["EmpName"];
                    model.EmpContact = (string)dt.Rows[i]["EmpContact"];
                    model.EmpEmail = (string)dt.Rows[i]["EmpEmail"];
                    model.EmpAddress = (string)dt.Rows[i]["EmpAddress"];
                }
                _list.Add(model);
            }
            return _list;
        }

        public string GenerateEmpcode()
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.GetEmpCode("spEmpCode");
            string empcode = (string)dt.Rows[0]["EmpCode"];
            return empcode;
        }
    }
}
