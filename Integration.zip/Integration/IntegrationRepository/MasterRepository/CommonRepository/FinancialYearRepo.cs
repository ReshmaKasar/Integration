﻿using IntegrationClsFunction.CommonFunction;
using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel.IntegrationErrorModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



    public class FinancialYearRepo : IFinancialYearInterface
{
    public List<FinancialYearModel> GetById(int id)
    {
        Connection con = new Connection();
        SqlConnection sqlcon = con.GetConnection();
        ClsFunction cls = new ClsFunction();
        DataTable dt = cls.fetchdata("Financial_Year", id);
        var _list = new List<FinancialYearModel>();
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            FinancialYearModel model = new FinancialYearModel();
            {
                model.YearId = (int)dt.Rows[i]["YearId"];
                model.Year = (DateTime)dt.Rows[i]["Year"];
            }
            _list.Add(model);
        }
        return _list;
    }

    public void DeleteById(int id)
    {
        ClsFunction cls = new ClsFunction();
        cls.DeleteById("Financial_Year", id);
    }

    public List<FinancialYearModel> GetYears()
    {
        FinancialYearModel model = null;
        ClsFunction cls = new ClsFunction();
        DataTable dt = cls.fetchdata("Financial_Year", 0);
        //FinancialYearModel fmodel = new FinancialYearModel();
        var _list = new List<FinancialYearModel>();
        try
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                model = new FinancialYearModel();
                {
                    model.YearId = (int)dt.Rows[i]["YearId"];
                    model.Year = (DateTime)dt.Rows[i]["Year"];
                }
                _list.Add(model);
            }
        }
        catch(Exception x)
        {
            ErrorLogModel errorLog = new ErrorLogModel();
            errorLog.ErrorCode = "01";
            errorLog.ErrorMassage = Convert.ToString(x);
            errorLog.ErrorStackTrace = Convert.ToString(x);
            errorLog.ErrorLineNo = Convert.ToString(x);
            errorLog.ErrorData = Convert.ToString(DateTime.Now); //problem
            errorLog.ErrorDateTime = Convert.ToString(DateTime.Now); //problem
            errorLog.SolvesStatus = Convert.ToString(x);
            errorLog.DeveloperName = "Sp";
            errorLog.FormName = Convert.ToString(x);
            errorLog.FunctionName = Convert.ToString(GetYears());
            errorLog.ClassName = Convert.ToString(x);
            errorLog.RepoName = Convert.ToString(x);
            errorLog.UserId = Convert.ToInt32(model.YearId);
            errorLog.flag = "i";
        }
        return _list;
    }

    public void PostData(FinancialYearModel model)
    {
        Connection con = new Connection();
        SqlConnection sqlcon = con.GetConnection();
        SqlCommand sqlcmd = new SqlCommand();
        sqlcmd.Connection = sqlcon;
        sqlcmd.CommandText = "spFinancial_Year";
        sqlcmd.CommandType = CommandType.StoredProcedure;

        string AcFlag = "Y";
        if (model.YearId == 0)
        {
            string flag = "i";
            sqlcmd.Parameters.AddWithValue("flag", flag);
        }
        else
        {
            string flag = "u";
            sqlcmd.Parameters.AddWithValue("flag", flag);
        }

        sqlcmd.Parameters.AddWithValue("@YearId", model.YearId);
        sqlcmd.Parameters.AddWithValue("@Year", model.Year);
        sqlcmd.Parameters.AddWithValue("@AcFlag", AcFlag);
        sqlcmd.ExecuteNonQuery();
    }

    public List<FinancialYearModel> GetByName(string name)
    {
        Connection con = new Connection();
        SqlConnection sqlcon = con.GetConnection();
        ClsFunction cls = new ClsFunction();
        DataTable dt = cls.FetchName("Financial_Year", name);
        var _list = new List<FinancialYearModel>();
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            FinancialYearModel model = new FinancialYearModel();
            {
                model.YearId = (int)dt.Rows[i]["YearId"];
                model.Year = (DateTime)dt.Rows[i]["Year"];
            }
            _list.Add(model);
        }
        return _list;
    }

}

