﻿//using IntegrationClsFunction.CommonFunction;
//using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
//using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
//using IntegrationModels.IntegrationMasterModel.CommonMasterModel.IntegrationErrorModel;
//using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.Data;
//using System.Data.SqlClient;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Web.Mvc;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel.IntegrationErrorModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IntegrationClsFunction.CommonFunction;
using System.Data.SqlClient;
using System.Web.Mvc;
using System.Collections;
using System.Runtime.InteropServices;
using IntegrationInterface.IntegrationMasterInterface.CommonInterface;

namespace IntegrationRepository.MasterRepository.CommonRepository
{
    public class UserRoleRepo : IUserRoleInterface
    {
        public List<UserRoleModel> GetRoles()
        {
            UserRoleModel model = null;
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.fetchdata("UserRole", 0);
            //UserRoleModel userRolemodel = new UserRoleModel();
            var _list = new List<UserRoleModel>();
            try
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    model = new UserRoleModel();
                    {
                        model.UserRoleId = (int)dt.Rows[i]["UserRoleId"];
                        model.UserId = (int)dt.Rows[i]["UserId"];
                        model.EmpId = (int)dt.Rows[i]["EmpId"];
                    }
                    _list.Add(model);
                }
                
            }
            catch (Exception x)
            {
                ErrorLogModel errorLog = new ErrorLogModel();
                errorLog.ErrorCode = "01";
                errorLog.ErrorMassage = Convert.ToString(x);
                errorLog.ErrorStackTrace = Convert.ToString(x);
                errorLog.ErrorLineNo = Convert.ToString(x);
                errorLog.ErrorData = Convert.ToString(DateTime.Now); //problem
                errorLog.ErrorDateTime = Convert.ToString(DateTime.Now); //problem
                errorLog.SolvesStatus = Convert.ToString(x);
                errorLog.DeveloperName = "Sp";
                errorLog.FormName = Convert.ToString(x);
                errorLog.FunctionName = Convert.ToString(GetRoles());
                errorLog.ClassName = Convert.ToString(x);
                errorLog.RepoName = Convert.ToString(x);
                errorLog.UserId = Convert.ToInt32(model.UserRoleId);
                errorLog.flag = "i";
            }
            return _list;
        }

        public void PostData(UserRoleModel model)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            SqlCommand sqlcmd = new SqlCommand();
            string AcFlag = "Y";
            sqlcmd.Connection = sqlcon;
            sqlcmd.CommandText = "spUserRole";
            sqlcmd.CommandType = CommandType.StoredProcedure;

            if (model.UserRoleId == 0)
            {
                string flag = "i";
                sqlcmd.Parameters.AddWithValue("flag", flag);
            }
            else
            {
                string flag = "u";
                sqlcmd.Parameters.AddWithValue("flag", flag);
            }

            sqlcmd.Parameters.AddWithValue("@UserRoleId", model.UserRoleId);
            sqlcmd.Parameters.AddWithValue("@UserId", model.UserId);
            sqlcmd.Parameters.AddWithValue("@EmpId", model.EmpId);
            sqlcmd.Parameters.AddWithValue("@AcFlag", AcFlag);
            sqlcmd.ExecuteNonQuery();
        }
        public List<UserRoleModel> GetById(int id)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.fetchdata("UserRole", id);
            var _list = new List<UserRoleModel>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                UserRoleModel model = new UserRoleModel();
                {
                    model.UserRoleId = (int)dt.Rows[i]["UserRoleId"];
                    model.UserId = (int)dt.Rows[i]["UserId"];
                    model.EmpId = (int)dt.Rows[i]["EmpId"];
                }
                _list.Add(model);
            }
            return _list;

        }
        public List<UserRoleModel> GetByName(string name)
        {
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            ClsFunction cls = new ClsFunction();
            DataTable dt = cls.FetchName("UserRole", name);
            var _list = new List<UserRoleModel>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                UserRoleModel model = new UserRoleModel();
                {
                    model.UserRoleId = (int)dt.Rows[i]["UserRoleId"];
                    model.UserId = (int)dt.Rows[i]["UserId"];
                    model.EmpId = (int)dt.Rows[i]["EmpId"];
                }
                _list.Add(model);
            }
            return _list;
        }
        public void DeleteById(int id)
        {
            ClsFunction cls = new ClsFunction();
            cls.DeleteById("UserRole", id);
        }

       

        public List<EmployeeModel> EmployeeDropdown()
        {
            string emplist = "select EmpId,EmpName from Employee where AcFlag='Y';";
            Connection conn = new Connection();
            SqlConnection sqlConnection = conn.GetConnection();
            ClsFunction cLSFuncation = new ClsFunction();
            DataTable dt = cLSFuncation.FetchDataTableQuery(emplist);
            ErrorLogModel errorLog = new ErrorLogModel();
            //var emodel = new EmployeeModel();
            var _list = new List<EmployeeModel>();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                EmployeeModel model = new EmployeeModel();
                {
                    model.EmpId = (int)dt.Rows[i]["EmpId"];
                   
                    model.EmpName = (string)dt.Rows[i]["EmpName"];
                    
                }
                _list.Add(model);
            }
            return _list;
        }

        public List<UserCreationModel> UserDropDown() //------------UserDropDown--------
        {
            string emplist = "select UserId,UserName from UserCreation where AcFlag='Y';";
            Connection conn = new Connection();
            SqlConnection sqlConnection = conn.GetConnection();
            ClsFunction cLSFuncation = new ClsFunction();
            DataTable dt = cLSFuncation.FetchDataTableQuery(emplist);
            ErrorLogModel errorLog = new ErrorLogModel();
            //var umodel = new UserCreationModel();
            var _list = new List<UserCreationModel>();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                UserCreationModel model = new UserCreationModel();
                {
                    model.UserId = (int)dt.Rows[i]["UserId"];
                    model.UserName = (string)dt.Rows[i]["UserName"];
                }
                _list.Add(model);
            }
           
            return _list;
        }
    }
}
