﻿using IntegrationClsFunction.CommonFunction;
using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel.IntegrationErrorModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace IntegrationRepository.MasterRepository.CommonRepository
{
    public  class PurchaseRequestLineRepo : ISavePurchaseRequest
    {
        public List<ItemModel> ItemDDL()
        {
            string itemlist = "select ItemId,ItemName from Item where AcFlag='Y';";
            Connection conn = new Connection();
            SqlConnection sqlConnection = conn.GetConnection();
            ClsFunction cLSFuncation = new ClsFunction();
            DataTable dt = cLSFuncation.FetchDataTableQuery(itemlist);
            ErrorLogModel errorLog = new ErrorLogModel();
            //var emodel = new ItemModel();
            var _list = new List<ItemModel>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ItemModel model = new ItemModel();
                {
                    model.ItemId = (int)dt.Rows[i]["ItemId"];
                    model.ItemName = (string)dt.Rows[i]["ItemName"];

                }
                _list.Add(model);
            }
            return _list;
        }

        public List<ProductModel> ProductDDL()
        {
            string productlist = "select ProductId,ProductName from Product where AcFlag='Y';";
            Connection conn = new Connection();
            SqlConnection sqlConnection = conn.GetConnection();
            ClsFunction cLSFuncation = new ClsFunction();
            DataTable dt = cLSFuncation.FetchDataTableQuery(productlist);
            ErrorLogModel errorLog = new ErrorLogModel();
            //var pmodel = new ProductModel();
            var _list = new List<ProductModel>();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ProductModel model = new ProductModel();
                {
                    model.ProductId = (int)dt.Rows[i]["ProductId"];
                    model.ProductName = (string)dt.Rows[i]["ProductName"];

                }
                _list.Add(model);
            }
            return _list;
        }

        public void SavePurchaseRequest(LineHeaderModel model)
        {
            HeaderModel Header = new HeaderModel();
            Header = model.Header;

            var Line = new List<LineModel>();
            Line = model.Line;
            Connection con = new Connection();
            SqlConnection sqlcon = con.GetConnection();
            SqlCommand sqlcmd = new SqlCommand();
            sqlcmd.Connection = sqlcon;
            sqlcmd.CommandText = "SpPurchase_Request_Header";
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@RequestHeaderId", Header.RequestHeaderId);
            sqlcmd.Parameters.AddWithValue("@RequestCode", Header.RequestCode);
            sqlcmd.Parameters.AddWithValue("@RequestBranchId", Header.RequestBranchId);
            sqlcmd.Parameters.AddWithValue("@RequestEmployeeId", Header.RequestEmployeeId);
            sqlcmd.Parameters.AddWithValue("@RequestDate", Header.RequestDate);
            
            sqlcmd.ExecuteNonQuery();
        }
    }
}
