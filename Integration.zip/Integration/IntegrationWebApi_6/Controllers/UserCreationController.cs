﻿using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IntegrationWebApi_6.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class UserCreationController : ControllerBase
    {
        UserCreationInterface userCreation;

        UserCreationController(UserCreationInterface init)
        {
            userCreation = init;
        }
        [HttpGet]
        public void GetAllUser()
        {
            userCreation.GetData();
        }

    }
}
