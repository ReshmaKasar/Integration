﻿using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntegrationInterface.IntegrationMasterInterface.CommonInterface
{
    //=================================================User Creation============================================
    public interface IUserCreationInterface
    {
        List<UserCreationModel> GetData();
        void PostData(UserCreationModel model);

        //void GetPost(UserCreationModel model);

        List<UserCreationModel> GetById(int id);
        List<UserCreationModel> GetByName(string name);

        void DeleteById(int id);
    }

    //=================================================User Role===================================================
    public interface IUserRoleInterface
    {
        List<UserRoleModel> GetRoles();
        //------------------- //Employee DropDown------------------------
        List<EmployeeModel> EmployeeDropdown();

        //------------------- //User DropDown------------------------
        List<UserCreationModel> UserDropDown();
        void PostData(UserRoleModel model);
        List<UserRoleModel> GetById(int id);
        List<UserRoleModel> GetByName(string name);
        void DeleteById(int id);
    }

    //================================================Models========================================================

    public interface IModelInterface
    {
        List<ModelModel> GetModels();
        void PostData(ModelModel model);
        List<ModelModel> GetById(int id);
        List<ModelModel> GetByName(string name);
        void DeleteById(int id);
    }

    //================================================FinancialYear================================================

    public interface IFinancialYearInterface
    {
        List<FinancialYearModel> GetYears();
        void PostData(FinancialYearModel model);
        List<FinancialYearModel> GetById(int id);
        List<FinancialYearModel> GetByName(string name);
        void DeleteById(int id);
    }

    //================================================Person================================================
    public interface IPersonInterface
    {
        List<PersonModel> GetPersons();
        void PostData(PersonModel model);
        List<PersonModel> GetById(int id);
        List<PersonModel> GetByName(string name);
        void DeleteById(int id);
    }

    //================================================Company================================================
    public interface ICompanyInterface
    {

        List<CompanyModel> GetCompanys();
        void PostData(CompanyModel model);
        List<CompanyModel> GetById(int id);
        List<CompanyModel> GetByName(string name);
        void DeleteById(int id);
    }

    //================================================Employee================================================
    public interface IEmployeeInterface
    {
        string GenerateEmpcode();
        List<EmployeeModel> GetEmployees();
        void PostData(EmployeeModel model);
        List<EmployeeModel> GetById(int id);
        List<EmployeeModel> GetByName(string name);
        void DeleteById(int id);
    }

    //================================================Product================================================
    public interface IProductInterface
    {
        List<ProductModel> GetProducts();
        void PostData(ProductModel model);
        List<ProductModel> GetById(int id);
        List<ProductModel> GetByName(string name);
        void DeleteById(int id);

        //------------------- //Product DropDown------------------------
        List<ProductModel> ProductDropDown();
    }

    //================================================Item================================================
    public interface IItemInterface
    {
        List<ItemModel> GetItems();
        void PostData(ItemModel model);
        List<ItemModel> GetById(int id);
        List<ItemModel> GetByName(string name);
        void DeleteById(int id);
        List<ItemModel> ItemDropDown();
    }

    //================================================Branch================================================
    public interface IBranch
    {
        //------------------- //Get All Item---------------------
        List<BranchModel> GetData();
        //------------------- //Get By Id-------------------------
        List<BranchModel> GetById(int id);
        //------------------- //Get By Name-----------------------
        List<BranchModel> GetByName(string name);

        //---------------------//Post-----------------------------
        void GetPost(BranchModel imodel);

        //------------------- //DeleteById------------------------
        void DeleteById(int id);

        //------------------- //Company DropDown------------------------
        List<CompanyModel> CompanyDropDown();
        //------------------- //Branch DropDown------------------------
        List<BranchModel> Companyid(int cid);
    }

    public interface IGodown
    {
        //------------------- //Get All Item---------------------
        List<GodownModel> GetData();
        //------------------- //get by id-------------------------
        List<GodownModel> GetById(int id);

        //------------------- //Get By Name-----------------------
        List<GodownModel> GetByName(string name);

        //---------------------//Post-----------------------------
        void GetPost(GodownModel gmodel);

        //------------------- //deletebyid------------------------
        void DeleteById(int id);

        //------------------- //Company DropDown------------------------
        List<CompanyModel> CompanyDropDown();
        //------------------- //Branch DropDown------------------------
        List<BranchModel> Companyid(int cid);
    }

    //--------------------------------------- ISavePurchaseRequest -------------------------------------------
    public interface ISavePurchaseRequest
    {
        List<ProductModel> ProductDDL();
        List<ItemModel> ItemDDL();
        void SavePurchaseRequest(LineHeaderModel model);
    }

}

