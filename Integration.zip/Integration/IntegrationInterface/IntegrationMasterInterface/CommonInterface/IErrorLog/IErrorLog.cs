﻿using IntegrationModels.IntegrationMasterModel.CommonMasterModel.IntegrationErrorModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace IntegrationInterface.IntegrationMasterInterface.CommonInterface.IErrorLog
{
    public class IErrorLog
    {
        public interface Error_Log_Interface
        {
            List<ErrorLogModel> GetData();
            //public void PostErrorLog(ErrorLogModel eModel);
        }
    }

    
}
