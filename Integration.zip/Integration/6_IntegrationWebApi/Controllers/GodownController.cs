﻿using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace _6_IntegrationWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GodownController : ControllerBase
    {
        private readonly IGodown godown;
        public GodownController(IGodown init)
        {
            godown = init;
        }

        //------------------- //Get All Branch---------------------
        [HttpGet]
        public List<GodownModel> GetAllUser()
        {
            var gmodel = new List<GodownModel>();
            gmodel = godown.GetData();
            return gmodel;
        }

        //------------------- //Get By Id-------------------------
        [HttpGet("id")]
        public List<GodownModel> GetById(int id)
        {
            List<GodownModel> gmodel;
            gmodel = godown.GetById(id);
            return gmodel;
        }

        //------------------- //Get By Name-------------------------
        [HttpGet("name")]
        public List<GodownModel> GetByName(string name)
        {
            List<GodownModel> gmodel;
            gmodel = godown.GetByName(name);
            return gmodel;
        }

        //---------------------//Post-----------------------
        [HttpPost]
        public void GetPost(GodownModel gmodel)
        {
            if (Isvalid(gmodel) == true)
            {
                godown.GetPost(gmodel);
            }

        }
        private bool Isvalid(GodownModel gmodel)
        {

            bool valid = true;

            if (gmodel.GodownName == "")
            {
                valid = false;
            }
            //else if (model.CompanyId == " ")
            //{
            //    valid = false;
            //}
            return valid;
        }

        //------------------- //Update-------------------------
        [HttpPut]
        public int Update(GodownModel gmodel)
        {
            godown.GetPost(gmodel);
            return 0;
        }

        //------------------- //DeleteById-------------------------
        [HttpDelete("id")]
        public void DeleteById(int id)
        {
            godown.DeleteById(id);
        }

        [HttpGet("CompanyDropDownList")] // Only Call //----------company DropDown------------
        public List<CompanyModel> CompanyDropDownList()
        {
            List<CompanyModel> gmodel;
            gmodel = godown.CompanyDropDown();
            return gmodel;

        }

        [HttpGet("cid")] // Only Call //----------Branch DropDown------------
        public List<BranchModel> BranchDropDownList(int cid)
        {
            List<BranchModel> branchm;
            branchm = godown.Companyid(cid);
            return branchm;

        }

    }
}

