﻿using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;

namespace _6_IntegrationWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        IEmployeeInterface employee;
        public EmployeeController(IEmployeeInterface init)
        {
            employee = init;
        }

        [HttpGet]
        public List<EmployeeModel> GetAllUser()
        {
            var _list = new List<EmployeeModel>();

            _list = employee.GetEmployees();

            return _list;
        }
        [HttpPost]
        public void PostData(EmployeeModel model)
        {
            employee.PostData(model);
        }

        private bool Isvalid(EmployeeModel model)
        {

            bool valid = true;

            if (model.EmpName == "")
            {
                valid = false;
            }
            else if (model.EmpContact == " ")
            {
                valid = false;
            }
            else if (model.EmpEmail == " ")
            {
                valid = false;
            }
            else if (model.EmpAddress == " ")
            {
                valid = false;
            }
            return valid;
        }

        [HttpGet("id")]
        public List<EmployeeModel> GetById(int id)
        {
            List<EmployeeModel> model;
            model = employee.GetById(id);
            return model;
        }

        [HttpGet("name")]
        public List<EmployeeModel> GetByName(string name)
        {
            List<EmployeeModel> model;
            model = employee.GetByName(name);
            return model;

        }

        [HttpPut]
        public int Update(EmployeeModel model)
        {
            employee.PostData(model);
            return 0;
        }

        [HttpDelete("id")]
        public void DeleteById(int id)
        {
            employee.DeleteById(id);
        }

        [HttpGet("EmpCode")]
        public string EmpCode()
        {
            return employee.GenerateEmpcode();
        }

    }
}
