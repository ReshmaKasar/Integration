﻿using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace _6_IntegrationWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FinancialYearController : ControllerBase
    {
        IFinancialYearInterface financeYear;
        public FinancialYearController(IFinancialYearInterface init)
        {
            financeYear = init;
        }

        [HttpGet]
        public List<FinancialYearModel> GetAllUser()
        {
            var _list = new List<FinancialYearModel>();

            _list = financeYear.GetYears();

            return _list;
        }
        [HttpPost]
        public void PostData(FinancialYearModel model)
        {
            financeYear.PostData(model);
        }

        [HttpGet("id")]
        public List<FinancialYearModel> GetById(int id)
        {
            List<FinancialYearModel> model;
            model = financeYear.GetById(id);
            return model;
        }

        [HttpGet("name")]
        public List<FinancialYearModel> GetByName(string name)
        {
            List<FinancialYearModel> model;
            model = financeYear.GetByName(name);
            return model;

        }

        [HttpPut]
        public int Update(FinancialYearModel model)
        {
            financeYear.PostData(model);
            return 0;
        }

        [HttpDelete("id")]
        public void DeleteById(int id)
        {
            financeYear.DeleteById(id);
        }
    }
}
