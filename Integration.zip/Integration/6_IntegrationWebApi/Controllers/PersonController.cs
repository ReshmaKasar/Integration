﻿using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;

namespace _6_IntegrationWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonController : ControllerBase
    {
        IPersonInterface person;
        public PersonController(IPersonInterface init)
        {
            person = init;
        }

        [HttpGet]
        public List<PersonModel> GetAllUser()
        {
            var _list = new List<PersonModel>();

            _list = person.GetPersons();

            return _list;
        }
        [HttpPost]
        public void PostData(PersonModel model)
        {
            person.PostData(model);
        }


        [HttpGet("id")]
        public List<PersonModel> GetById(int id)
        {
            List<PersonModel> model;
            model = person.GetById(id);
            return model;
        }

        [HttpGet("name")]
        public List<PersonModel> GetByName(string name)
        {
            List<PersonModel> model;
            model = person.GetByName(name);
            return model;

        }

        [HttpPut]
        public int Update(PersonModel model)
        {
            person.PostData(model);
            return 0;
        }

        [HttpDelete("id")]
        public void DeleteById(int id)
        {
            person.DeleteById(id);
        }
    }
}
