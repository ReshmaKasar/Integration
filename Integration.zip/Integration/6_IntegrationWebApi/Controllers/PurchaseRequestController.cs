﻿using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace _6_IntegrationWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PurchaseRequestController : ControllerBase
    {
        ISavePurchaseRequest iPurchaseRequest;
        public PurchaseRequestController(ISavePurchaseRequest ipur)
        {
            iPurchaseRequest = ipur;
        }
        [HttpGet("ProductDDl")]     // Only Call //----------Product DropDown------------
        public List<ProductModel>productddl()
        {
            return iPurchaseRequest.ProductDDL();
        }

        [HttpGet("ItemDropDownList")] // Only Call //----------item DropDown------------
        public List<ItemModel> itemDDL()
        {

            return iPurchaseRequest.ItemDDL();

        }

    }
}
