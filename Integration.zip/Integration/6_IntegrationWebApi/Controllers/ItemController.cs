﻿using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Reflection;

namespace _6_IntegrationWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemController : ControllerBase
    {
        IItemInterface item;
        public ItemController(IItemInterface init)
        {
            item = init;
        }

        [HttpGet]
        public List<ItemModel> GetAllUser()
        {
            var _list = new List<ItemModel>();

            _list = item.GetItems();

            return _list;
        }
        [HttpPost]
        public void PostData(ItemModel model)
        {
            item.PostData(model);
        }


        [HttpGet("id")]
        public List<ItemModel> GetById(int id)
        {
            List<ItemModel> model;
            model = item.GetById(id);
            return model;
        }

        [HttpGet("name")]
        public List<ItemModel> GetByName(string name)
        {
            List<ItemModel> model;
            model = item.GetByName(name);
            return model;

        }

        [HttpPut]
        public int Update(ItemModel model)
        {
            item.PostData(model);
            return 0;
        }

        [HttpDelete("id")]
        public void DeleteById(int id)
        {
            item.DeleteById(id);
        }

        [HttpGet("ItemDropDownList")] // Only Call //----------Product DropDown------------
        public List<ItemModel> Product()
        {
            List<ItemModel> items;
            items = item.ItemDropDown();
            return items;

        }
    }
}
