﻿using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace _6_IntegrationWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserCreationController : ControllerBase
    {
        IUserCreationInterface usercreation;
       public UserCreationController(IUserCreationInterface init)
        {
            usercreation = init;
        }

        [HttpGet]
        public List<UserCreationModel> GetAllUser()
        {
            var _list = new List<UserCreationModel>();

            _list = usercreation.GetData();

            return _list;
        }
        [HttpPost]
        public void PostData(UserCreationModel model)
        {
            usercreation.PostData(model);
        }

        [HttpGet("id")]
        public List<UserCreationModel> GetById(int id)
        {
            List<UserCreationModel> model;
            model = usercreation.GetById(id);
            return model;
        }

        [HttpGet("name")]
        public List<UserCreationModel> GetByName(string name)
        {
            List<UserCreationModel> model;
            model = usercreation.GetByName(name);
            return model;

        }

        

        [HttpPut]
        public int Update(UserCreationModel model)
        {
            usercreation.PostData(model);
            return 0;
        }

        [HttpDelete("id")]
        public void DeleteById(int id)
        {
            usercreation.DeleteById(id);
        }
    }

}
