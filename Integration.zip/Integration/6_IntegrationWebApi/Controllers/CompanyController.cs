﻿using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;

namespace _6_IntegrationWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompanyController : ControllerBase
    {
        ICompanyInterface company;
        public CompanyController(ICompanyInterface init)
        {
            company = init;
        }

        [HttpGet]
        public List<CompanyModel> GetAllUser()
        {
            var _list = new List<CompanyModel>();

            _list = company.GetCompanys();

            return _list;
        }
        [HttpPost]
        public void PostData(CompanyModel model)
        {
            if (Isvalid(model) == true)
            {
                company.PostData(model);
            }
        }

        private bool Isvalid(CompanyModel model)
        {

            bool valid = true;

            if (model.CompanyName == "")
            {
                valid = false;
            }
            else if (model.Companyemail == " ")
            {
                valid = false;
            }
            else if (model.CompanyContact == " ")
            {
                valid = false;
            }
            else if (model.CompanyLogo == " ")
            {
                valid = false;
            }
            return valid;
        }

        //------------------- //Get By Id-------------------------
        [HttpGet("id")]
        public List<CompanyModel> GetById(int id)
        {
            List<CompanyModel> model;
            model = company.GetById(id);
            return model;
        }

        //------------------- //Get By Name-------------------------
        [HttpGet("name")]
        public List<CompanyModel> GetByName(string name)
        {
            List<CompanyModel> model;
            model = company.GetByName(name);
            return model;

        }

        //------------------- //Update-------------------------
        [HttpPut]
        public int Update(CompanyModel model)
        {
            company.PostData(model);
            return 0;
        }

        //------------------- //DeleteById-------------------------
        [HttpDelete("id")]
        public void DeleteById(int id)
        {
            company.DeleteById(id);
        }
    }
}
