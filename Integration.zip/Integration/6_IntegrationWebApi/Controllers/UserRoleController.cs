﻿using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using IntegrationRepository.MasterRepository.CommonRepository;
using System.Reflection;

namespace _6_IntegrationWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserRoleController : ControllerBase
    {
        readonly IUserRoleInterface userrole;
        public UserRoleController(IUserRoleInterface init)
        {
            userrole = init;
        }

        [HttpGet]
        public List<UserRoleModel> GetAllUser()
        {
            var _list = new List<UserRoleModel>();

            _list = userrole.GetRoles();

            return _list;
        }
        [HttpPost]
        public void PostData(UserRoleModel model)
        {
            userrole.PostData(model);
        }

        [HttpGet("id")]
        public List<UserRoleModel> GetById(int id)
        {
            List<UserRoleModel> model;
            model = userrole.GetById(id);
            return model;
        }

        [HttpGet("name")]
        public List<UserRoleModel> GetByName(string name)
        {
            List<UserRoleModel> model;
            model = userrole.GetByName(name);
            return model;

        }

        [HttpPut]
        public int Update(UserRoleModel model)
        {
            userrole.PostData(model);
            return 0;
        }

        [HttpDelete("id")]
        public void DeleteById(int id)
        {
            userrole.DeleteById(id);
        }

        [HttpGet("EmployeeDropDownList")]

        public List<EmployeeModel> EmpDetails()  // Only Call //----------Employee DropDown------------
        {
            var _list = new List<EmployeeModel>();

            _list = userrole.EmployeeDropdown();

            return _list;
        }
        

        [HttpGet("UserDropDownList")] // Only Call //----------User DropDown------------
        public List<UserCreationModel> User()
        {
            List<UserCreationModel> user;
            user = userrole.UserDropDown();
            return user;

        }
    }
}
