﻿using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;

namespace _6_IntegrationWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ModelController : ControllerBase
    {
        IModelInterface model1;
        public ModelController(IModelInterface init)
        {
            model1 = init;
        }

        [HttpGet]
        public List<ModelModel> GetAllUser()
        {
            var _list = new List<ModelModel>();

            _list = model1.GetModels();

            return _list;
        }
        [HttpPost]
        public void PostData(ModelModel model)
        {
            model1.PostData(model);
        }

        [HttpGet("id")]
        public List<ModelModel> GetById(int id)
        {
            List<ModelModel> model;
            model = model1.GetById(id);
            return model;
        }

        [HttpGet("name")]
        public List<ModelModel> GetByName(string name)
        {
            List<ModelModel> model;
            model = model1.GetByName(name);
            return model;

        }

        [HttpPut]
        public int Update(ModelModel model)
        {
            model1.PostData(model);
            return 0;
        }

        [HttpDelete("id")]
        public void DeleteById(int id)
        {
            model1.DeleteById(id);
        }
    }
}
