﻿using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace _6_IntegrationWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BranchController : ControllerBase
    {
        private readonly IBranch branch;
        public BranchController(IBranch init)
        {
            branch = init;
        }

        //------------------- //Get All Branch---------------------
        [HttpGet]
        public List<BranchModel> GetAllUser()
        {
            var branchmodel = new List<BranchModel>();
            branchmodel = branch.GetData();
            return branchmodel;
        }

        //------------------- //Get By Id-------------------------
        [HttpGet("id")]
        public List<BranchModel> GetById(int id)
        {
            List<BranchModel> umodel;
            umodel = branch.GetById(id);
            return umodel;
        }

        //------------------- //Get By Name-------------------------
        [HttpGet("name")]
        public List<BranchModel> GetByName(string name)
        {
            List<BranchModel> umodel;
            umodel = branch.GetByName(name);
            return umodel;
        }

        //---------------------//Post-----------------------
        [HttpPost]
        public void GetPost(BranchModel umodel)
        {
            if (Isvalid(umodel) == true)
            {
                branch.GetPost(umodel);
            }

        }
        private bool Isvalid(BranchModel model)
        {

            bool valid = true;

            if (model.BranchName == "")
            {
                valid = false;
            }
            //else if (model.CompanyId == " ")
            //{
            //    valid = false;
            //}
            return valid;
        }

        //------------------- //Update-------------------------
        [HttpPut]
        public int Update(BranchModel umodel)
        {
            branch.GetPost(umodel);
            return 0;
        }

        //------------------- //DeleteById-------------------------
        [HttpDelete("id")]
        public void DeleteById(int id)
        {
            branch.DeleteById(id);
        }

        [HttpGet("CompanyDropDownList")] // Only Call //----------company DropDown------------
        public List<CompanyModel> CompanyDropDownList()
        {
            List<CompanyModel> company;
            company = branch.CompanyDropDown();
            return company;

        }

        [HttpGet("cid")] // Only Call //----------Branch DropDown------------
        public List<BranchModel> BranchDropDownList(int cid)
        {
            List<BranchModel> branchm;
            branchm = branch.Companyid(cid);
            return branchm;

        }

    }
}

