﻿using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using IntegrationRepository.MasterRepository.CommonRepository;
using System;

namespace _6_IntegrationWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        IProductInterface productc;
        public ProductController(IProductInterface init)
        {
            productc = init;
        }

        [HttpGet]
        public List<ProductModel> GetAllUser()
        {
            var _list = new List<ProductModel>();

            _list = productc.GetProducts();

            return _list;
        }
        [HttpPost]
        public void PostData(ProductModel model)
        {
            productc.PostData(model);
        }

        [HttpGet("id")]
        public List<ProductModel> GetById(int id)
        {
            List<ProductModel> model;
            model = productc.GetById(id);
            return model;
        }

        [HttpGet("name")]
        public List<ProductModel> GetByName(string name)
        {
            List<ProductModel> model;
            model = productc.GetByName(name);
            return model;

        }

        [HttpPut]
        public int Update(ProductModel model)
        {
            productc.PostData(model);
            return 0;
        }

        [HttpDelete("id")]
        public void DeleteById(int id)
        {
            productc.DeleteById(id);
        }

        [HttpGet("ProductDropDownList")] // Only Call //----------Product DropDown------------
        public List<ProductModel> Product()
        {
            List<ProductModel> products;
            products = productc.ProductDropDown();
            return products;

        }
    }
    
}
