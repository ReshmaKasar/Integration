using _6_IntegrationWebApi.Controllers;
using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;
using IntegrationRepository.MasterRepository.CommonRepository;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();


// builders
builder.Services.AddScoped<IUserCreationInterface, UserCreationRepo>();
builder.Services.AddScoped<IUserRoleInterface, UserRoleRepo>();
builder.Services.AddScoped<IProductInterface, ProductRepo>();
builder.Services.AddScoped<IPersonInterface, PersonRepo>();
builder.Services.AddScoped<IModelInterface, ModelRepo>();
builder.Services.AddScoped<IItemInterface, ItemRepo>();
builder.Services.AddScoped<IFinancialYearInterface, FinancialYearRepo>();
builder.Services.AddScoped<IEmployeeInterface, EmployeeRepo>();
builder.Services.AddScoped<ICompanyInterface, CompanyRepo>();
builder.Services.AddScoped<IBranch, BranchRepository>();
builder.Services.AddScoped<IGodown, GodownRepo>();
builder.Services.AddScoped<ISavePurchaseRequest, PurchaseRequestLineRepo>();


var app = builder.Build();

app.UseCors(builder => {
    builder.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod();
});

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();

app.MapControllers();

app.Run();
