﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using IntegrationInterface.IntegrationMasterInterface.CommonInterface;
using IntegrationModels.IntegrationMasterModel.CommonMasterModel;

namespace IntegrationWebApi_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserCreationController : ControllerBase
    {
        UserCreationInterface usercreation;
        UserCreationController(UserCreationInterface init)
        {
            usercreation = init;
        }

        [HttpGet]
        public List<UserCreationModel> GetAllUser()
        {
            var _list = new List<UserCreationModel>();

           _list=usercreation.GetData();

            return _list;
        }
    }
}
