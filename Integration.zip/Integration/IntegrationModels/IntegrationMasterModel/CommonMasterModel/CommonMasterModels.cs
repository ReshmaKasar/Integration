﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntegrationModels.IntegrationMasterModel.CommonMasterModel
{

    public class UserCreationModel   //UserCreationModel
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        //public string AcFlag { get; set; }

    }
    public class UserRoleModel
    {
        public int UserRoleId { get; set; }
        public int UserId { get; set; }
        public int EmpId { get; set; }
    }
    public class ModelModel
    {
        public int ModelId { get; set; }
        public string FeedMill { get; set; }

        public string Hitechary { get; set; }

        public string Integration { get; set; }

        public string Breater { get; set; }

    }
    public class FinancialYearModel
    {
        public int YearId { get; set; }
        public DateTime Year { get; set; }
    }
    public class PersonModel
    {
        public int PersonId { get; set; }
        public int PersonCode { get; set; }
        public string PersonType { get; set; }
        public string PersonName { get; set; }
        public string PersonAddress { get; set; }
        public string PersonContact { get; set; }
        public string PersonEmail { get; set; }
        public int PersonBankId { get; set; }
    }
    public class CompanyModel
    {
        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
        public string Companyemail { get; set; }
        public string CompanyContact { get; set; }
        public string CompanyLogo { get; set; }

    }
    public class EmployeeModel
    {
        public int EmpId { get; set; }
        public string EmpCode { get; set; }
        public string EmpName { get; set; }
        public string EmpContact { get; set; }
        public string EmpEmail { get; set; }
        public string EmpAddress { get; set; }
    }
    public class ProductModel
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
    }
    public class ItemModel
    {
        public int ItemId { get; set; }
        public string ItemCode { get; set; }
        public int ProdcutId { get; set; }
        public string ItemName { get; set; }
        public int ItemStd { get; set; }
    }

    public class BranchModel
    {
        public int BranchId { get; set; }
        public string BranchName { get; set; }
        public int CompanyId { get; set; }
    }

    public class GodownModel
    {
        public int GodownId { get; set; }
        public int CompanyId { get; set; }
        public int BranchId { get; set; }
        public string GodownName { get; set; }


    }

    //----------------------------------------   LineHeaderModel ------------------------------------
    public class LineHeaderModel
    {
        public HeaderModel Header { get; set; }
        public List<LineModel> Line { get; set; }
    }

    public class LineModel
    {
        public int RequestLineId { get; set; }
        public int RequestHeaderId { get; set; }
        public int ProductId { get; set; }
        public int ItemId { get; set; }
        public decimal ItemMaxQuantity { get; set; }
        public decimal ItemMinQuantity { get; set; }

    }

    public class HeaderModel
    {
        public int RequestHeaderId { get; set; }
        public string RequestCode { get; set; }
        public int RequestBranchId { get; set; }
        public int RequestEmployeeId { get; set; }
        public DateTime RequestDate { get; set; }
    }

}
