﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntegrationModels.IntegrationMasterModel.CommonMasterModel.IntegrationErrorModel
{
    public class ErrorLogModel
    {
        public int ErrorId { get; set; }
        public string ErrorName { get; set; }
        public string FormName { get; set; }
        public string FunctionName { get; set; }
        public string ClassName { get; set; }
        public string RepoName { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorMassage { get; set; }
        public string ErrorStackTrace { get; set; }
        public string ErrorLineNo { get; set; }
        public int UserId { get; set; }
        public string ErrorData { get; set; }
        public string ErrorDateTime { get; set; }
        public string SolvesStatus { get; set; }
        public string DeveloperName { get; set; }

        public string flag { get; set; }
    }
}
