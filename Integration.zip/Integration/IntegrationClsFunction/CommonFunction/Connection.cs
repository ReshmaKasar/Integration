﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntegrationClsFunction.CommonFunction
{
    public class Connection
    {
        public SqlConnection GetConnection()
        {
            string connectionstring = "Data Source=LAPTOP-0T38B4U1\\SQLEXPRESS;Initial Catalog=DbIntegration;User Id=sa;Password=Game@123;Integrated Security=True;";
            SqlConnection connection = new SqlConnection(connectionstring);
            connection.Close();
            connection.Open();
            return connection;
        }

        public SqlConnection GetErrorLogConnection()
        {
            string connectionstring = "Data Source=LAPTOP-0T38B4U1\\SQLEXPRESS;Initial Catalog=DbIntegrationError;User Id=sa;Password=Game@123;Integrated Security=True;";
            SqlConnection connection = new SqlConnection(connectionstring);
            connection.Close();
            connection.Open();
            return connection;
        }

    }
}
