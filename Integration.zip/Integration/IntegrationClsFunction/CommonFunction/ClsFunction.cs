﻿using IntegrationModels.IntegrationMasterModel.CommonMasterModel.IntegrationErrorModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;


namespace IntegrationClsFunction.CommonFunction
{
    public class ClsFunction
    {
        public DataTable fetchdata( string table,int id) //------------------- //Get All Users-------------------------
        {

            Connection conn = new Connection();
            SqlConnection sqlcon = conn.GetConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlcon;
            cmd.CommandType = CommandType.StoredProcedure;
            if (id == 0)  //------------------- //Get All Users-------------------------
            {
                
                
                cmd.CommandText = "spAllReports";
                cmd.Parameters.AddWithValue("@flag", table);
                
            }
            else        //------------------- //Get By Id-------------------------
            {
                cmd.CommandText = "spAllReportsById";  
                cmd.Parameters.AddWithValue("@flag", table);
                cmd.Parameters.AddWithValue("@id", id);
                
            }
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;

        }

        public DataTable FetchName(string table , string name)   //------------------- //FetchName-------------------------
        {

            Connection conn = new Connection();
            SqlConnection sqlcon = conn.GetConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlcon;
            cmd.CommandType = CommandType.StoredProcedure;
    

            cmd.CommandText = "spAllReportsByName";
            cmd.Parameters.AddWithValue("@flag", table);
            cmd.Parameters.AddWithValue("@name", name);
            

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;

        }

        public void DeleteById(string table, int id)  //------------------- //DeleteById-------------------------
        {

            Connection conn = new Connection();
            SqlConnection sqlcon = conn.GetConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlcon;
            cmd.CommandType = CommandType.StoredProcedure;


            cmd.CommandText = "spAllReportsDeleteById";
            cmd.Parameters.AddWithValue("@flag", table);
            cmd.Parameters.AddWithValue("@id", id);

            cmd.ExecuteNonQuery();

        }


        public void PostErrorLog(ErrorLogModel eModel)
        {
            Connection connection = new Connection();
            SqlConnection sqlcon = connection.GetErrorLogConnection();
            SqlCommand cmd = new SqlCommand();

            cmd.Connection = sqlcon;
            cmd.CommandText = "spErrorLong";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@ErrorName", eModel. ErrorName);
            cmd.Parameters.AddWithValue("@ErrorCode", eModel.ErrorCode);
            cmd.Parameters.AddWithValue("@ErrorMassage", eModel.ErrorMassage);
            cmd.Parameters.AddWithValue("@ErrorStackTrace", eModel.ErrorStackTrace);
            cmd.Parameters.AddWithValue("@ErrorLineNo", eModel.ErrorLineNo);
            cmd.Parameters.AddWithValue("@ErrorData", eModel.ErrorData);
            cmd.Parameters.AddWithValue("@ErrorDateTime", eModel.ErrorDateTime);
            cmd.Parameters.AddWithValue("@SolveStatus", eModel.SolvesStatus);
            cmd.Parameters.AddWithValue("@DeveloperName", eModel.DeveloperName);
            cmd.Parameters.AddWithValue("@FormName", eModel.FormName);
            cmd.Parameters.AddWithValue("@FunctionName", eModel.FunctionName);
            cmd.Parameters.AddWithValue("@ClassName", eModel.ClassName);
            cmd.Parameters.AddWithValue("@RepoName", eModel.RepoName);
            cmd.Parameters.AddWithValue("@UserId", eModel.UserId);
            cmd.Parameters.AddWithValue("@flag", eModel.flag);

            cmd.ExecuteNonQuery();


        }



        public DataTable GetEmpCode(string storeprocedurename)  //------------------- //Get By Name-------------------------
        {

            Connection conn = new Connection();
            SqlConnection sqlcon = conn.GetConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlcon;
            cmd.CommandText = storeprocedurename;
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public DataTable FetchDataTableQuery(string emplist)
        {
            Connection conn = new Connection();
            SqlConnection sqlcon = conn.GetConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlcon;
            cmd.CommandText = emplist;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

    }
}
